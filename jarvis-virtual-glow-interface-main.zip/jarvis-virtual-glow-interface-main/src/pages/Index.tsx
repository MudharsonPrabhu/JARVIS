
import { JarvisInterface } from '@/components/JarvisInterface';

const Index = () => {
  return <JarvisInterface />;
};

export default Index;
